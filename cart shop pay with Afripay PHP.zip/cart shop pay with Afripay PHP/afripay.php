<? 
$payment_method=$_POST['payment_method'];
$client_token=$_POST['client_token'];
$payment_currency=$_POST['currency'];
$payment_status=$_POST['status'];
$amount=$_POST['amount'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group2 | Afripay</title>


</head>
<body>

    <br/><br/><br/><br/><br/>
    <center>
    <div style="border-color: rgb(72, 72, 155) ; background-color: chocolate; color:aliceblue; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; height: 330px; width:360px;">
        
    <form action="https://www.afripay.africa/checkout/index.php" method="post" id="afripayform" class="form-popup" >
        <br/><center><h3 style="color:yellow; font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif">MTN MOMO PAY</h3>
        Amount<input type="number" name="amount" value="200" > <br/>
        currency<input  name="currency" value="RWF"><br/>
        comment<input  name="comment" value="Order 122"><br/>
        client_token<input  name="client_token" value="" ><br/>
        return_url<input  name="return_url" value="" ><br/>
        app_id<input  name="app_id" value="f1726776df7d6361605332ae3d52c513"><br/>
        app_secret<input  name="app_secret" value="JDJ5JDEwJGtBdDEw"><br/>
        <p>
        <input type="image" src="https://www.afripay.africa/logos/pay_with_afripay.png" alt="Pay with AfriPay" onclick="document.afripayform.submit();">
        </p>
        </center>
        </form>

    </div>
</center>
<br/><br/><br/><br/><br/><br/><br/>
<footer>
    <div style="background-color:chocolate;color:aliceblue;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;width:100%;height:30px;">
    <h3><center>Developed by David Gloire</center></h3>
    </div>
</footer>
</body>
</html>
