
<? 
$payment_method=$_POST['payment_method'];
$client_token=$_POST['client_token'];
$payment_currency=$_POST['currency'];
$payment_status=$_POST['status'];
$amount=$_POST['amount'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GOUP2 | PAYMENT</title>
    
</head>

<body>
    <a href="cart.php"><button style="color:white; background-color:teal;height:40px;width:80px;"><strong>Back</strong></button></a>
    <center>
        <br/><br/>
        <div style="background-color: rgb(11, 54, 78); color:aliceblue;font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;height:180px;width:200px;">
            <form>
                <br/><br/> EMAIL <input type="text" ; placeholder="Enter email adress" autocomplete="on" id="email" />
                <br/> PRICE <input type="text" placeholder="Enter the price" autocomplete="on" id="price" />
                <br/><br/>
                <button type="button" style="background-color: rgb(252, 95, 38); color:aliceblue; height: 30px; width:60px;">PAY</button>

            </form>
        </div>
    </center>
</body>

</html>