<?
$payment_method=$_POST['payment_method'];
$client_token=$_POST['client_token'];
$payment_currency=$_POST['currency'];
$payment_status=$_POST['status'];
$amount=$_POST['amount'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group2 | Afripay</title>


</head>
<body>
<br/><center>
<div style="border-color: rgb(72, 72, 155) ; background-color: chocolate; color:aliceblue; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; height: 510px; width:200px;">
        <form name="afripayform" method="POST" action="https://afripay.africa/checkout/index.php">
            <center>             
        amount <input type="number" name="amount"  required>
        <input type="hidden" name="currency" value="RWF">
        client_token <input type="hidden"  name="client_token" placeholder="Enter client_token" value="" >
        <input  name="return_url" type="hidden" placeholder="Enter return_url" value="http://localhost/group2/" >
        firstname <input placeholder="Enter First Name" type="text" required>
        lastname <input placeholder="Enter Last Name" type="text">
        street <input placeholder="Enter Street" type="text">
        city <input placeholder="Enter City" type="text">
        <input placeholder="Enter State" type="hidden">
        zip_code <input placeholder="Enter zip_code" type="number">
        <input type="hidden" placeholder="Enter country" value="Rwanda">
        email <input placeholder="Enter Email" type="text">
        phone <input placeholder="Enter phone number" type="number">
        comment<input  name="comment" placeholder="Enter comment" style="height: 70px;">
        <input type="hidden" name="app_id" value="f1726776df7d6361605332ae3d52c513" readonly>
        <input  type="hidden" name="app_secret" value="JDJ5JDEwJGtBdDEw" readonly>
        <button type="button" onclick="document.afripayform.submit();" style="background-color: white;color:orangered;height:30px;width:90px;"><strong>Continue</strong></button>
        <script>
            Alert("Transaction was successfully made!");
            </script>
    </center>
        </form>
    </div>
    </center>
</body>
</html>