<?php

session_start();
$status="";
if (isset($_POST['action']) && $_POST['action']=="remove"){
if(!empty($_SESSION["shopping_cart"])) {
	foreach($_SESSION["shopping_cart"] as $key => $value) {
		if($_POST["code"] == $key){
		unset($_SESSION["shopping_cart"][$key]);
		$status = "<div class='box' style='color:red;'>
		Product is removed from your cart!</div>";
		}
		if(empty($_SESSION["shopping_cart"]))
		unset($_SESSION["shopping_cart"]);
			}		
		}
}

if (isset($_POST['action']) && $_POST['action']=="change"){
  foreach($_SESSION["shopping_cart"] as &$value){
    if($value['code'] === $_POST["code"]){
        $value['quantity'] = $_POST["quantity"];
        break; 
    }
}
  	
}
?>
<html>
<head>
<title>DavyPay | CART</title>
<link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
</head>
<body>
<a href="index.php"><button style="color:white; background-color:teal;height:40px;width:80px;"><strong>Back</strong></button></a>
<div style="width:700px; margin:50 auto;">

<h2 style="background-color:rgb(252, 95, 38); color:white;font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><center>DAVYPAY CART</center></h2>   

<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="cart_div">
<a href="cart.php">
<img src="cart-icon.png" /> Cart
<span><?php echo $cart_count; ?></span></a>
</div>
<?php
}
?>

<div class="cart" style="background-color:grey;height:200px;width:600px;">
<?php
if(isset($_SESSION["shopping_cart"])){
    $total_price = 0;
?>	
<table class="table">
<tbody>
<tr>
<td></td>
<td>ITEM NAME</td>
<td>QUANTITY</td>
<td>UNIT PRICE</td>
<td>ITEMS TOTAL</td>
</tr>	
<?php		
foreach ($_SESSION["shopping_cart"] as $product){
?>
<tr>
<td><img src='<?php echo $product["image"]; ?>' width="50" height="40" /></td>
<td><?php echo $product["name"]; ?><br />
<form method='post' action=''>
<input type='hidden' name='code' value="<?php echo $product["code"]; ?>" />
<input type='hidden' name='action' value="remove" />
<button type='submit' class='remove'>Remove Item</button>
</form>
</td>
<td>
<form method='post' action=''>
<input type='hidden' name='code' value="<?php echo $product["code"]; ?>" />
<input type='hidden' name='action' value="change" />
<select name='quantity' class='quantity' onchange="this.form.submit()">
<option <?php if($product["quantity"]==1) echo "selected";?> value="1">1</option>
<option <?php if($product["quantity"]==2) echo "selected";?> value="2">2</option>
<option <?php if($product["quantity"]==3) echo "selected";?> value="3">3</option>
<option <?php if($product["quantity"]==4) echo "selected";?> value="4">4</option>
<option <?php if($product["quantity"]==5) echo "selected";?> value="5">5</option>
</select>
</form>
</td>
<td><?php echo "RWF".$product["price"]; ?></td>
<td><?php echo "RWF".$product["price"]*$product["quantity"]; ?></td>
</tr>
<?php
$total_price += ($product["price"]*$product["quantity"]);
}
?>
<tr>
<td colspan="5" align="right">
<strong>TOTAL: <?php echo "RWF".$total_price; ?></strong>
</td>
</tr>
</tbody>
</table>		
  <?php
}else{
	echo "<h3>Your cart is empty!</h3>";
	}
?>
</div>

<div style="clear:both;"></div>

<div class="message_box" style="margin:10px 0px;">
<?php echo $status; ?>
</div>


<br /><br />
<!-- <center><a href="https://ravesandbox.flutterwave.com/pay/gloiredavid0jby?_gl=1%2a1pk9iu%2a_ga%2aMTQzNjc3MDIxLjE2NTQ2MjQ3ODE.%2a_ga_KQ9NSEMFCF%2aMTY1NDY4MTM2OS4zLjEuMTY1NDY4Mzg5Ny4w"><button style="color:white; background-color:rgb(252, 95, 38);height:40px;width:80px;"><strong>PAY</strong></button></a></center> -->
<!--<a href="callback.php"><button style="color:white; background-color:orangered; color: white; height:60px;width:100;"><strong>pay</strong></button></a>-->
</div>

<div>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}


.open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 80px;
  right: 28px;
  width: 280px;
}


.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}


.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}


.form-container input[type=text], .form-container input[type=number] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}


.form-container input[type=text]:focus, .form-container input[type=number]:focus {
  background-color: #ddd;
  outline: none;
}


.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}


.form-container .cancel {
  background-color: orangered;
}


.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>



<button class="open-button" onclick="openForm()">Make Payment</button>

<div class="form-popup" id="myForm">
  <form class="form-container" name="afripayform" method="POST" action="https://afripay.africa/checkout/index.php">
    <h1 style="color:orangered ;"><center>TRANSACTION</center></h1>

	<label for="email"><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="fn" required>

    <input  name="return_url" type="hidden" placeholder="Enter return_url" value="http://localhost/group2/" >
    <input type="hidden" placeholder="Enter country" value="Rwanda">
    <input type="hidden" name="app_id" value="f1726776df7d6361605332ae3d52c513" readonly>
        <input  type="hidden" name="app_secret" value="JDJ5JDEwJGtBdDEw" readonly>
        <input type="hidden" name="currency" value="RWF">
    <label for="psw"><b>Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="ln" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="amount"><b>Amount</b></label>
    <input type="number" placeholder="Enter Amount" name="amount" value=<?php echo $total_price ?> required>

    <button type="submit" class="btn" onclick="document.afripayform.submit();">PAY</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
</div>

<br/><br/><br/><br/><br/><br/><br/>
<footer>
    <div style="background-color:chocolate;color:aliceblue;font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;width:100%;height:40px;">
    <h3><strong><center>Developed by David Gloire</center></strong></h3>
    </div>
</footer>
</body>
</html>